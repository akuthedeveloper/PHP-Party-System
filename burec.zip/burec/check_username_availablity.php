<?php
$con=mysqli_connect("localhost","root","","hotel");
if($_REQUEST)
{
	$username 	= $_REQUEST['uname'];
	$query = "select * from user where userName = '".strtolower($username)."'";
	$results = mysqli_query($con, $query) or die('ok');
	
	if(mysqli_num_rows(@$results) > 0) // not available
	{
		echo '<div id="Error">Already Taken Try Another Username</div>';
	}
	else
	{
		echo '<div id="Success">Available</div>';
	}
	
}?>