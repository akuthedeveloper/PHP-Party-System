<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title></title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="dashboard.php" class="logo"> <b>BUREC</b></a>
            <!--logo end-->
            
                    
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="login.html">Log In </a></li>            	
                <li><a href="" class="logout" data-toggle="dropdown" >                    
					voke
					<!--sessions-->
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
				  
                    <li><a href="#">
					<div data-toggle="modal" data-target="#voke">
					<i class="fa fa-user fa-fw pull-right"></i> Profile
					<div class="clearfix"></div>
						</div>
					</a>
					</li>	          
                    
                    <li><a href="logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                 </ul>
                </li>

                
                  </ul>
                </li>
              </ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
                  <p class="centered"><a href="profile.html"><img src="assets/img/back.png" class="img-circle" width="140"></a></p>
              	  <h5 class="centered">welcome</h5>
              	  	
                  <li class="mt">
                      <a  class="active" href="dashboard.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>                      </a>                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Donation</span>                      </a>
                      <ul class="sub">
                          <li><a  href="general.html">Donate</a></li>
                         
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Events</span>                      </a>
                      <ul class="sub">
                          <li><a  href="calendar.html">Add event</a></li>
                          </ul>
                  </li>              
                  
                 
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          	<h3><i class="fa fa-angle-right"></i> SUMMARY </h3>
          	
                        
                        <div class="row mt">
                      <!-- SERVER STATUS PANELS -->
                      	<div class="col-md-4 col-sm-4 mb">
                      		<div class="white-panel pn donut-chart">
                      			<div class="white-header">
						  			<h5>STATUTS</h5>
                      			</div>
								<div class="row">
									<div class="col-sm-6 col-xs-6 goleft">
										<!--<p><i class="fa fa-database"></i> 70%</p>-->
									</div>
	                      		</div>
								<div >
                                                                   
                                                                        <b>CHAPITRE I : CREATION, DENOMINATION, EMBLEME ET SIEGE</b>
                                                                        <p> Article 1: Il est cree en Republique Democratique du Congo, entre les personnes physiques adherents......</p>
                                                                      
                                                                        <br><br>
                                                                        <a href="pdf/1.pdf" class="btn btn-info" role="button">Continue Reading</a>

                                                                    
                                                                                                                                               
	                      		</div>
								
	                      	</div><! --/grey-panel -->
                      	</div><!-- /col-md-4-->
                      	

                      	<div class="col-md-4 col-sm-4 mb">
                      		<div class="white-panel pn">
                      			<div class="white-header">
						  			<h5>PROJET DE SOCIETE</h5>
                      			</div>
								<div class="row">
									<div class="col-sm-6 col-xs-6 goleft">
										<!--<p><i class="fa fa-heart"></i> 122</p>-->
									</div>
									<div class="col-sm-6 col-xs-6"></div>
	                      		</div>
	                      		<div>
                                            <b>PLAN</b>
                                            <br>
                                            <b style="float:left; padding-left: 10px">PREAMBULE</b>
                                            <br>
                                            <b style="float:left; padding-left: 10px">I. IDEES - FORCES</b>
                                            <br>
                                            <p>I.1. Une vision politique puisee des valeurs intrinseques de la social - democratie.</p>
                                            <br>
                                                                        <a href="pdf/2.pdf" class="btn btn-info" role="button">Continue Reading</a>
	                      		</div>
                      		</div>
                      	</div><!-- /col-md-4 -->
                      	
						<div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>REGLEMENT INTERIEUR</h5>
								</div>
                                                            <b>REGLEMENT INTERIEUR</b>
                                                            <br>
                                                            <b>CHAPITRE I : DE LA DEFINITION ET DU CHAMP D'ACTION</b><br>
                                                            <p>Article 1 : Le present Reglement Interieur precise et complete les dispositions des Statuts du Parti
politique.....</p> 
                                                            
                                                                        <a href="pdf/3.pdf" class="btn btn-info" role="button">Continue Reading</a>
							</div>
						</div><!-- /col-md-4 -->
                      	
                  </p>
          		</div>
          	</div>
			
		</section><! --wrapper -->
                
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
             &copy; BUREC <script type="text/javascript">
var theDate=new Date()
document.write(theDate.getFullYear())
</script>
              <a href="blank.html#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
